public class PedidoExpress extends Pedido
        implements Despachable, Cancelable {

    public PedidoExpress(int idPedido, String direccionEntrega, double distancia) {
        super(idPedido, direccionEntrega, distancia);
    }

    @Override
    public void asignarRepartidor() {
        System.out.println("[Pedido Express]");
        System.out.println("Buscando repartidor más cercano...");
        setRepartidor("Camila Soto");
        System.out.println("Repartidor asignado: " + getRepartidor());
    }

    @Override
    public int calcularTiempoEntrega() {
        return (int) (getDistancia() * 3);
    }

    @Override
    public void despachar() {
        System.out.println("Pedido express despachado correctamente.");
    }

    @Override
    public void cancelar() {
        System.out.println("Pedido Express #" + getIdPedido() + " cancelado exitosamente.");
    }
}