public class PedidoComida extends Pedido
        implements Despachable, Cancelable {

    public PedidoComida(int idPedido, String direccionEntrega, double distancia) {
        super(idPedido, direccionEntrega, distancia);
    }

    @Override
    public void asignarRepartidor() {
        System.out.println("[Pedido Comida]");
        System.out.println("Buscando repartidor con mochila térmica...");
        setRepartidor("Luis Díaz");
        System.out.println("Repartidor asignado: " + getRepartidor());
    }

    @Override
    public int calcularTiempoEntrega() {
        return (int) (getDistancia() * 4);
    }

    @Override
    public void despachar() {
        System.out.println("Pedido de comida despachado correctamente.");
    }

    @Override
    public void cancelar() {
        System.out.println("Pedido de comida #" + getIdPedido() + " cancelado.");
    }
}