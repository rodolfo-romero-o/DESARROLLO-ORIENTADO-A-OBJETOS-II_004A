public class Main {

    public static void main(String[] args) {

        ControladorDeEnvios controlador = new ControladorDeEnvios();

        PedidoComida comida = new PedidoComida(
                101,
                "Av. Camilo Henriquez 123",
                5
        );

        PedidoEncomienda encomienda = new PedidoEncomienda(
                102,
                "Av. Santa Rosa 567",
                7
        );

        PedidoExpress express = new PedidoExpress(
                103,
                "Av. Vicuña Mackenna 900",
                4
        );

        System.out.println("===== SPEEDFAST =====");

        // PEDIDO COMIDA

        comida.asignarRepartidor();

        comida.mostrarResumen();

        System.out.println(
                "Tiempo estimado: "
                        + comida.calcularTiempoEntrega()
                        + " minutos"
        );

        comida.despachar();

        controlador.registrarEntrega(comida);

        System.out.println("\n---------------------------\n");

        // PEDIDO ENCOMIENDA

        encomienda.asignarRepartidor("Daniela Tapia");

        encomienda.mostrarResumen();

        System.out.println(
                "Tiempo estimado: "
                        + encomienda.calcularTiempoEntrega()
                        + " minutos"
        );

        encomienda.despachar();

        controlador.registrarEntrega(encomienda);

        System.out.println("\n---------------------------\n");

        // PEDIDO EXPRESS

        express.asignarRepartidor();

        express.mostrarResumen();

        System.out.println(
                "Tiempo estimado: "
                        + express.calcularTiempoEntrega()
                        + " minutos"
        );

        express.cancelar();

        // HISTORIAL

        controlador.verHistorial();
    }
}