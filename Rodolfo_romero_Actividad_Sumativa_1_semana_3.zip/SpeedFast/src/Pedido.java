public abstract class Pedido {

    private int idPedido;
    private String direccionEntrega;
    private double distancia;
    private String repartidor;

    public Pedido(int idPedido, String direccionEntrega, double distancia) {
        this.idPedido = idPedido;
        this.direccionEntrega = direccionEntrega;
        this.distancia = distancia;
        this.repartidor = "Sin asignar";
    }

    // Método normal implementado
    public void mostrarResumen() {
        System.out.println("Pedido #" + idPedido);
        System.out.println("Dirección: " + direccionEntrega);
        System.out.println("Distancia: " + distancia + " km");
        System.out.println("Repartidor asignado: " + repartidor);
    }

    // Método para sobrescribir
    public void asignarRepartidor() {
        System.out.println("Buscando repartidor disponible...");
    }

    // Sobrecarga
    public void asignarRepartidor(String nombre) {
        repartidor = nombre;
        System.out.println("Pedido asignado manualmente a " + nombre);
    }

    // Método abstracto
    public abstract int calcularTiempoEntrega();

    public int getIdPedido() {
        return idPedido;
    }

    public String getDireccionEntrega() {
        return direccionEntrega;
    }

    public double getDistancia() {
        return distancia;
    }

    public String getRepartidor() {
        return repartidor;
    }

    public void setRepartidor(String repartidor) {
        this.repartidor = repartidor;
    }
}