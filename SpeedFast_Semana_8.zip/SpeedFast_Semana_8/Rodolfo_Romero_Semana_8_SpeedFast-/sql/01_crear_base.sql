CREATE DATABASE IF NOT EXISTS speedfast_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE speedfast_db;

CREATE TABLE IF NOT EXISTS repartidor (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    CONSTRAINT chk_repartidor_nombre CHECK (CHAR_LENGTH(TRIM(nombre)) > 0)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS pedido (
    id INT AUTO_INCREMENT PRIMARY KEY,
    direccion VARCHAR(150) NOT NULL,
    tipo VARCHAR(30) NOT NULL,
    estado VARCHAR(20) NOT NULL,
    CONSTRAINT chk_pedido_direccion CHECK (CHAR_LENGTH(TRIM(direccion)) > 0),
    CONSTRAINT chk_pedido_tipo CHECK (tipo IN ('COMIDA','ENCOMIENDA','EXPRESS')),
    CONSTRAINT chk_pedido_estado CHECK (estado IN ('PENDIENTE','EN_REPARTO','ENTREGADO'))
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS entrega (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_pedido INT NOT NULL,
    id_repartidor INT NOT NULL,
    fecha DATE NOT NULL,
    hora TIME NOT NULL,
    CONSTRAINT fk_entrega_pedido FOREIGN KEY (id_pedido) REFERENCES pedido(id) ON DELETE RESTRICT ON UPDATE RESTRICT,
    CONSTRAINT fk_entrega_repartidor FOREIGN KEY (id_repartidor) REFERENCES repartidor(id) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB;
-- No hay UNIQUE(id_pedido): el modelo permite varias entregas/etapas.
SHOW TABLES;
SHOW CREATE TABLE repartidor;
SHOW CREATE TABLE pedido;
SHOW CREATE TABLE entrega;
