USE speedfast_db;
SELECT id, nombre FROM repartidor ORDER BY id;
SELECT id, direccion, tipo, estado FROM pedido ORDER BY id;
SELECT e.id, e.id_pedido, p.direccion, e.id_repartidor, r.nombre,
       e.fecha, e.hora
FROM entrega e
JOIN pedido p ON p.id = e.id_pedido
JOIN repartidor r ON r.id = e.id_repartidor
ORDER BY e.id;
