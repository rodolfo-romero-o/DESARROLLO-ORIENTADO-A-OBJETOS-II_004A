package cl.speedfast.modelo;
public enum TipoPedido { COMIDA, ENCOMIENDA, EXPRESS }
