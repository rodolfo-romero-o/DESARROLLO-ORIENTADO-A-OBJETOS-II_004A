package cl.speedfast.dao;
import java.io.IOException;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public final class ConexionBD {
    private ConexionBD() { }
    public static Connection conectar() throws SQLException {
        Properties datos = new Properties();
        Path archivo = Path.of("config", "db.properties");

        try (Reader lector = Files.newBufferedReader(archivo, StandardCharsets.UTF_8)) {
            datos.load(lector);
        } catch (IOException e) {
            throw new SQLException("No se pudo leer config/db.properties. Copie el archivo de ejemplo y configure MySQL.", e);
        }
        String url = datos.getProperty("db.url", "").trim();
        String usuario = datos.getProperty("db.user", "").trim();
        String clave = datos.getProperty("db.password");
        if (!url.startsWith("jdbc:mysql://") || usuario.isEmpty() || clave == null)
            throw new SQLException("Complete db.url, db.user y db.password en config/db.properties.");
        try {
            return DriverManager.getConnection(url, usuario, clave);
        } catch (SQLException e) {
            throw new SQLException("No se pudo conectar a MySQL. Revise servicio, base de datos, usuario y contraseña.",
                    e.getSQLState(), e.getErrorCode(), e);
        }
    }

    public static void cerrar(AutoCloseable recurso) {
        if (recurso != null) {
            try { recurso.close(); }
            catch (Exception e) { System.err.println("No se pudo cerrar un recurso JDBC: " + e.getClass().getSimpleName()); }
        }
    }
}
