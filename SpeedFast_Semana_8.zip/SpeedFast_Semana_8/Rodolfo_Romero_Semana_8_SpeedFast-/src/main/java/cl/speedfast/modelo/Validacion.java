package cl.speedfast.modelo;

public final class Validacion {
    private Validacion() { }
    public static String texto(String valor, String campo, int maximo) {
        if (valor == null || valor.isBlank()) throw new IllegalArgumentException(campo + " es obligatorio.");
        String limpio = valor.strip();
        if (limpio.codePointCount(0, limpio.length()) > maximo)
            throw new IllegalArgumentException(campo + " admite hasta " + maximo + " caracteres.");
        return limpio;
    }
    public static int id(int valor, String campo) {
        if (valor <= 0) throw new IllegalArgumentException(campo + " debe ser un ID positivo.");
        return valor;
    }
}
