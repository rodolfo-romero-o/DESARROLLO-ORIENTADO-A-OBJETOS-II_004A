package cl.speedfast.modelo;
public class Repartidor {
    private final int id;
    private final String nombre;
    public Repartidor(String nombre) { this(0, nombre); }
    public Repartidor(int id, String nombre) {
        if (id < 0) throw new IllegalArgumentException("ID inválido.");
        this.id = id;
        this.nombre = Validacion.texto(nombre, "Nombre", 100);
    }
    public int getId() { return id; }
    public String getNombre() { return nombre; }
    @Override public String toString() { return id + " - " + nombre; }
}
