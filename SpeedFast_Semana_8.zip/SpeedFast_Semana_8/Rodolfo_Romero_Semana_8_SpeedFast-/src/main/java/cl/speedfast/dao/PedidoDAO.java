package cl.speedfast.dao;
import cl.speedfast.modelo.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PedidoDAO {
    public int guardar(Pedido dato) throws SQLException {
        String sql = "INSERT INTO pedido (direccion, tipo, estado) VALUES (?, ?, ?)";
        try (Connection cn = ConexionBD.conectar(); PreparedStatement ps = cn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, dato.getDireccion()); ps.setString(2, dato.getTipo().name()); ps.setString(3, dato.getEstado().name());
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) { if (rs.next()) return rs.getInt(1); }
        }
        throw new SQLException("No se pudo guardar pedido.");
    }

    public List<Pedido> listarTodos() throws SQLException {
        List<Pedido> lista = new ArrayList<>();
        String sql = "SELECT * FROM pedido ORDER BY id";
        try (Connection cn = ConexionBD.conectar(); PreparedStatement ps = cn.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) lista.add(new Pedido(rs.getInt("id"), rs.getString("direccion"), TipoPedido.valueOf(rs.getString("tipo")), EstadoPedido.valueOf(rs.getString("estado"))));
        }
        return lista;
    }

    public boolean actualizar(Pedido dato) throws SQLException {
        String sql = "UPDATE pedido SET direccion=?, tipo=?, estado=? WHERE id=?";
        try (Connection cn = ConexionBD.conectar(); PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setString(1, dato.getDireccion()); ps.setString(2, dato.getTipo().name()); ps.setString(3, dato.getEstado().name()); ps.setInt(4, dato.getId());
            return ps.executeUpdate() == 1;
        }
    }

    public boolean eliminar(int id) throws SQLException {
        String sql = "DELETE FROM pedido WHERE id=?";
        try (Connection cn = ConexionBD.conectar(); PreparedStatement ps = cn.prepareStatement(sql)) { ps.setInt(1, id); return ps.executeUpdate() == 1; }
    }
}
