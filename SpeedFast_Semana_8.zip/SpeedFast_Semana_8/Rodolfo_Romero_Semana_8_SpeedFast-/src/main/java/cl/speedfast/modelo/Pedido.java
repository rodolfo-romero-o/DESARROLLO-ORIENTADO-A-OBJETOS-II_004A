package cl.speedfast.modelo;
public class Pedido {
    private final int id;
    private final String direccion;
    private final TipoPedido tipo;
    private final EstadoPedido estado;
    public Pedido(String direccion, TipoPedido tipo, EstadoPedido estado) { this(0, direccion, tipo, estado); }
    public Pedido(int id, String direccion, TipoPedido tipo, EstadoPedido estado) {
        if (id < 0) throw new IllegalArgumentException("ID inválido.");
        if (tipo == null || estado == null) throw new IllegalArgumentException("Seleccione tipo y estado.");
        this.id = id;
        this.direccion = Validacion.texto(direccion, "Dirección", 150);
        this.tipo = tipo;
        this.estado = estado;
    }
    public int getId() { return id; }
    public String getDireccion() { return direccion; }
    public TipoPedido getTipo() { return tipo; }
    public EstadoPedido getEstado() { return estado; }
    @Override public String toString() { return id + " - " + direccion; }
}
