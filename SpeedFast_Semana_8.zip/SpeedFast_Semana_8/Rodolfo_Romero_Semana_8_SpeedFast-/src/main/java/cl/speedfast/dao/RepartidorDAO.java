package cl.speedfast.dao;
import cl.speedfast.modelo.Repartidor;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class RepartidorDAO {
    public int guardar(Repartidor dato) throws SQLException {
        String sql = "INSERT INTO repartidor (nombre) VALUES (?)";
        try (Connection cn = ConexionBD.conectar();
             PreparedStatement ps = cn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, dato.getNombre());
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) return rs.getInt(1);
            }
        }
        throw new SQLException("No se pudo guardar repartidor.");
    }

    public List<Repartidor> listarTodos() throws SQLException {
        List<Repartidor> lista = new ArrayList<>();
        String sql = "SELECT * FROM repartidor ORDER BY id";
        try (Connection cn = ConexionBD.conectar(); PreparedStatement ps = cn.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) lista.add(new Repartidor(rs.getInt("id"), rs.getString("nombre")));
        }
        return lista;
    }

    public boolean actualizar(Repartidor dato) throws SQLException {
        String sql = "UPDATE repartidor SET nombre=? WHERE id=?";
        try (Connection cn = ConexionBD.conectar(); PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setString(1, dato.getNombre()); ps.setInt(2, dato.getId());
            return ps.executeUpdate() == 1;
        }
    }

    public boolean eliminar(int id) throws SQLException {
        String sql = "DELETE FROM repartidor WHERE id=?";
        try (Connection cn = ConexionBD.conectar(); PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setInt(1, id); return ps.executeUpdate() == 1;
        }
    }
}
