package cl.speedfast.modelo;
import java.time.LocalDate;
import java.time.LocalTime;

public class Entrega {
    private final int id;
    private final int idPedido;
    private final int idRepartidor;
    private final LocalDate fecha;
    private final LocalTime hora;

    public Entrega(int idPedido, int idRepartidor, LocalDate fecha, LocalTime hora) {
        this(0, idPedido, idRepartidor, fecha, hora);
    }

    public Entrega(int id, int idPedido, int idRepartidor, LocalDate fecha, LocalTime hora) {
        if (id < 0) throw new IllegalArgumentException("ID inválido.");
        this.id = id;
        this.idPedido = Validacion.id(idPedido, "Pedido");
        this.idRepartidor = Validacion.id(idRepartidor, "Repartidor");
        if (fecha == null || hora == null) throw new IllegalArgumentException("Fecha y hora son obligatorias.");
        this.fecha = fecha;
        this.hora = hora.withNano(0);
    }

    public int getId() { return id; }
    public int getIdPedido() { return idPedido; }
    public int getIdRepartidor() { return idRepartidor; }
    public LocalDate getFecha() { return fecha; }
    public LocalTime getHora() { return hora; }
}
