package cl.speedfast.dao;
import cl.speedfast.modelo.Entrega;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EntregaDAO {
    public int guardar(Entrega dato) throws SQLException {
        String sql = "INSERT INTO entrega (id_pedido, id_repartidor, fecha, hora) VALUES (?, ?, ?, ?)";
        try (Connection cn = ConexionBD.conectar(); PreparedStatement ps = cn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            cargar(ps, dato); ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) { if (rs.next()) return rs.getInt(1); }
        }
        throw new SQLException("No se pudo guardar entrega.");
    }

    public List<Entrega> listarTodos() throws SQLException {
        List<Entrega> lista = new ArrayList<>();
        String sql = "SELECT * FROM entrega ORDER BY id";
        try (Connection cn = ConexionBD.conectar(); PreparedStatement ps = cn.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) lista.add(new Entrega(rs.getInt("id"), rs.getInt("id_pedido"), rs.getInt("id_repartidor"), rs.getDate("fecha").toLocalDate(), rs.getTime("hora").toLocalTime()));
        }
        return lista;
    }

    public boolean actualizar(Entrega dato) throws SQLException {
        String sql = "UPDATE entrega SET id_pedido=?, id_repartidor=?, fecha=?, hora=? WHERE id=?";
        try (Connection cn = ConexionBD.conectar(); PreparedStatement ps = cn.prepareStatement(sql)) {
            cargar(ps, dato); ps.setInt(5, dato.getId()); return ps.executeUpdate() == 1;
        }
    }

    public boolean eliminar(int id) throws SQLException {
        String sql = "DELETE FROM entrega WHERE id=?";
        try (Connection cn = ConexionBD.conectar(); PreparedStatement ps = cn.prepareStatement(sql)) { ps.setInt(1, id); return ps.executeUpdate() == 1; }
    }

    private void cargar(PreparedStatement ps, Entrega dato) throws SQLException {
        ps.setInt(1, dato.getIdPedido()); ps.setInt(2, dato.getIdRepartidor()); ps.setDate(3, Date.valueOf(dato.getFecha())); ps.setTime(4, Time.valueOf(dato.getHora()));
    }
}
