package cl.speedfast.vista;

import cl.speedfast.dao.*;
import cl.speedfast.modelo.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;
import java.util.List;

public class VentanaPrincipal extends JFrame {
    private final PedidoDAO pedidoDAO = new PedidoDAO();
    private final RepartidorDAO repartidorDAO = new RepartidorDAO();
    private final EntregaDAO entregaDAO = new EntregaDAO();

    private final JTextField direccion = new JTextField(25);
    private final JComboBox<TipoPedido> tipo = new JComboBox<>(TipoPedido.values());
    private final JComboBox<EstadoPedido> estado = new JComboBox<>(EstadoPedido.values());
    private final JTable tablaPedidos = new JTable(modelo("ID", "Dirección", "Tipo", "Estado"));

    private final JTextField nombre = new JTextField(25);
    private final JTable tablaRepartidores = new JTable(modelo("ID", "Nombre"));

    private final JComboBox<Pedido> pedidoEntrega = new JComboBox<>();
    private final JComboBox<Repartidor> repartidorEntrega = new JComboBox<>();
    private final JTextField fecha = new JTextField(LocalDate.now().toString());
    private final JTextField hora = new JTextField(LocalTime.now().withSecond(0).withNano(0).toString());
    private final JTable tablaEntregas = new JTable(modelo("ID", "Pedido", "Repartidor", "Fecha", "Hora"));

    public VentanaPrincipal() {
        super("SpeedFast | Semana 8 | CRUD completo");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(950, 620);
        setLocationRelativeTo(null);

        JTabbedPane tabs = new JTabbedPane();
        tabs.addTab("Pedidos", panelPedidos());
        tabs.addTab("Repartidores", panelRepartidores());
        tabs.addTab("Entregas", panelEntregas());
        add(tabs);

        cargarTodo();
    }

    private JPanel panelPedidos() {
        JPanel formulario = new JPanel(new GridLayout(0, 2, 8, 8));
        campo(formulario, "Dirección", direccion);
        campo(formulario, "Tipo", tipo);
        campo(formulario, "Estado", estado);
        formulario.add(boton("Registrar", this::guardarPedido));
        formulario.add(boton("Editar seleccionado", this::editarPedido));
        formulario.add(boton("Eliminar seleccionado", this::eliminarPedido));
        formulario.add(boton("Actualizar tabla", this::cargarPedidos));
        tablaPedidos.getSelectionModel().addListSelectionListener(e -> seleccionarPedido());
        return panelConTabla(formulario, tablaPedidos);
    }

    private JPanel panelRepartidores() {
        JPanel formulario = new JPanel(new GridLayout(0, 2, 8, 8));
        campo(formulario, "Nombre", nombre);
        formulario.add(boton("Registrar", this::guardarRepartidor));
        formulario.add(boton("Editar seleccionado", this::editarRepartidor));
        formulario.add(boton("Eliminar seleccionado", this::eliminarRepartidor));
        formulario.add(boton("Actualizar tabla", this::cargarRepartidores));
        tablaRepartidores.getSelectionModel().addListSelectionListener(e -> seleccionarRepartidor());
        return panelConTabla(formulario, tablaRepartidores);
    }

    private JPanel panelEntregas() {
        JPanel formulario = new JPanel(new GridLayout(0, 2, 8, 8));
        campo(formulario, "Pedido", pedidoEntrega);
        campo(formulario, "Repartidor", repartidorEntrega);
        campo(formulario, "Fecha (AAAA-MM-DD)", fecha);
        campo(formulario, "Hora (HH:mm)", hora);
        formulario.add(boton("Registrar", this::guardarEntrega));
        formulario.add(boton("Editar seleccionado", this::editarEntrega));
        formulario.add(boton("Eliminar seleccionado", this::eliminarEntrega));
        formulario.add(boton("Actualizar tabla", this::cargarEntregas));
        tablaEntregas.getSelectionModel().addListSelectionListener(e -> seleccionarEntrega());
        return panelConTabla(formulario, tablaEntregas);
    }

    private JButton boton(String texto, Runnable accion) {
        JButton b = new JButton(texto);
        b.addActionListener(e -> {
            try { accion.run(); }
            catch (IllegalArgumentException | DateTimeParseException ex) { error(ex.getMessage()); }
        });
        return b;
    }

    private void guardarPedido() {
        try {
            Pedido p = new Pedido(direccion.getText(), (TipoPedido) tipo.getSelectedItem(), (EstadoPedido) estado.getSelectedItem());
            int id = pedidoDAO.guardar(p);
            mensaje("Pedido registrado con ID " + id);
            direccion.setText(""); cargarPedidos(); cargarCombos();
        } catch (SQLException e) { errorSQL(e); }
    }

    private void editarPedido() {
        int fila = tablaPedidos.getSelectedRow();
        if (fila < 0) throw new IllegalArgumentException("Seleccione un pedido en la tabla.");
        int id = idSeleccionado(tablaPedidos);
        try {
            Pedido p = new Pedido(id, direccion.getText(), (TipoPedido) tipo.getSelectedItem(), (EstadoPedido) estado.getSelectedItem());
            if (pedidoDAO.actualizar(p)) mensaje("Pedido actualizado correctamente.");
            cargarPedidos(); cargarCombos();
        } catch (SQLException e) { errorSQL(e); }
    }

    private void eliminarPedido() {
        if (tablaPedidos.getSelectedRow() < 0) throw new IllegalArgumentException("Seleccione un pedido en la tabla.");
        if (!confirmar("¿Eliminar el pedido seleccionado?")) return;
        try { pedidoDAO.eliminar(idSeleccionado(tablaPedidos)); cargarPedidos(); cargarCombos(); }
        catch (SQLException e) { errorSQL(e); }
    }

    private void cargarPedidos() {
        try {
            DefaultTableModel m = (DefaultTableModel) tablaPedidos.getModel(); m.setRowCount(0);
            for (Pedido p : pedidoDAO.listarTodos()) m.addRow(new Object[]{p.getId(), p.getDireccion(), p.getTipo(), p.getEstado()});
        } catch (SQLException e) { errorSQL(e); }
    }

    private void guardarRepartidor() {
        try {
            int id = repartidorDAO.guardar(new Repartidor(nombre.getText()));
            mensaje("Repartidor registrado con ID " + id);
            nombre.setText(""); cargarRepartidores(); cargarCombos();
        } catch (SQLException e) { errorSQL(e); }
    }

    private void editarRepartidor() {
        if (tablaRepartidores.getSelectedRow() < 0) throw new IllegalArgumentException("Seleccione un repartidor en la tabla.");
        try {
            repartidorDAO.actualizar(new Repartidor(idSeleccionado(tablaRepartidores), nombre.getText()));
            mensaje("Repartidor actualizado correctamente."); cargarRepartidores(); cargarCombos();
        } catch (SQLException e) { errorSQL(e); }
    }

    private void eliminarRepartidor() {
        if (tablaRepartidores.getSelectedRow() < 0) throw new IllegalArgumentException("Seleccione un repartidor en la tabla.");
        if (!confirmar("¿Eliminar el repartidor seleccionado?")) return;
        try { repartidorDAO.eliminar(idSeleccionado(tablaRepartidores)); cargarRepartidores(); cargarCombos(); }
        catch (SQLException e) { errorSQL(e); }
    }

    private void cargarRepartidores() {
        try {
            DefaultTableModel m = (DefaultTableModel) tablaRepartidores.getModel(); m.setRowCount(0);
            for (Repartidor r : repartidorDAO.listarTodos()) m.addRow(new Object[]{r.getId(), r.getNombre()});
        } catch (SQLException e) { errorSQL(e); }
    }

    private void guardarEntrega() {
        Pedido p = (Pedido) pedidoEntrega.getSelectedItem(); Repartidor r = (Repartidor) repartidorEntrega.getSelectedItem();
        if (p == null || r == null) throw new IllegalArgumentException("Debe seleccionar pedido y repartidor.");
        try {
            Entrega en = new Entrega(p.getId(), r.getId(), LocalDate.parse(fecha.getText().trim()), LocalTime.parse(hora.getText().trim()));
            int id = entregaDAO.guardar(en); mensaje("Entrega registrada con ID " + id); cargarEntregas();
        } catch (SQLException e) { errorSQL(e); }
    }

    private void editarEntrega() {
        if (tablaEntregas.getSelectedRow() < 0) throw new IllegalArgumentException("Seleccione una entrega en la tabla.");
        Pedido p = (Pedido) pedidoEntrega.getSelectedItem(); Repartidor r = (Repartidor) repartidorEntrega.getSelectedItem();
        if (p == null || r == null) throw new IllegalArgumentException("Debe seleccionar pedido y repartidor.");
        try {
            Entrega en = new Entrega(idSeleccionado(tablaEntregas), p.getId(), r.getId(), LocalDate.parse(fecha.getText().trim()), LocalTime.parse(hora.getText().trim()));
            entregaDAO.actualizar(en); mensaje("Entrega actualizada correctamente."); cargarEntregas();
        } catch (SQLException e) { errorSQL(e); }
    }

    private void eliminarEntrega() {
        if (tablaEntregas.getSelectedRow() < 0) throw new IllegalArgumentException("Seleccione una entrega en la tabla.");
        if (!confirmar("¿Eliminar la entrega seleccionada?")) return;
        try { entregaDAO.eliminar(idSeleccionado(tablaEntregas)); cargarEntregas(); }
        catch (SQLException e) { errorSQL(e); }
    }

    private void cargarEntregas() {
        try {
            DefaultTableModel m = (DefaultTableModel) tablaEntregas.getModel(); m.setRowCount(0);
            for (Entrega e : entregaDAO.listarTodos()) m.addRow(new Object[]{e.getId(), e.getIdPedido(), e.getIdRepartidor(), e.getFecha(), e.getHora()});
        } catch (SQLException e) { errorSQL(e); }
    }

    private void cargarCombos() {
        try {
            List<Pedido> ps = pedidoDAO.listarTodos(); List<Repartidor> rs = repartidorDAO.listarTodos();
            pedidoEntrega.removeAllItems(); repartidorEntrega.removeAllItems();
            ps.forEach(pedidoEntrega::addItem); rs.forEach(repartidorEntrega::addItem);
        } catch (SQLException e) { errorSQL(e); }
    }

    private void cargarTodo() { cargarPedidos(); cargarRepartidores(); cargarCombos(); cargarEntregas(); }

    private void seleccionarPedido() {
        int f = tablaPedidos.getSelectedRow(); if (f < 0) return; f = tablaPedidos.convertRowIndexToModel(f);
        DefaultTableModel m = (DefaultTableModel) tablaPedidos.getModel();
        direccion.setText(m.getValueAt(f, 1).toString()); tipo.setSelectedItem(TipoPedido.valueOf(m.getValueAt(f, 2).toString())); estado.setSelectedItem(EstadoPedido.valueOf(m.getValueAt(f, 3).toString()));
    }

    private void seleccionarRepartidor() {
        int f = tablaRepartidores.getSelectedRow(); if (f < 0) return; f = tablaRepartidores.convertRowIndexToModel(f);
        nombre.setText(tablaRepartidores.getModel().getValueAt(f, 1).toString());
    }

    private void seleccionarEntrega() {
        int f = tablaEntregas.getSelectedRow(); if (f < 0) return; f = tablaEntregas.convertRowIndexToModel(f);
        int idP = Integer.parseInt(tablaEntregas.getModel().getValueAt(f, 1).toString());
        int idR = Integer.parseInt(tablaEntregas.getModel().getValueAt(f, 2).toString());
        seleccionarCombo(pedidoEntrega, idP); seleccionarCombo(repartidorEntrega, idR);
        fecha.setText(tablaEntregas.getModel().getValueAt(f, 3).toString()); hora.setText(tablaEntregas.getModel().getValueAt(f, 4).toString());
    }

    private void seleccionarCombo(JComboBox<?> combo, int id) {
        for (int i=0; i<combo.getItemCount(); i++) {
            Object o=combo.getItemAt(i);
            if (o instanceof Pedido p && p.getId()==id) combo.setSelectedIndex(i);
            if (o instanceof Repartidor r && r.getId()==id) combo.setSelectedIndex(i);
        }
    }

    private int idSeleccionado(JTable tabla) {
        int f = tabla.convertRowIndexToModel(tabla.getSelectedRow());
        return Integer.parseInt(tabla.getModel().getValueAt(f, 0).toString());
    }

    private static DefaultTableModel modelo(String... columnas) {
        return new DefaultTableModel(columnas, 0) { public boolean isCellEditable(int f, int c) { return false; } };
    }
    private static void campo(JPanel p, String texto, JComponent c) { p.add(new JLabel(texto)); p.add(c); }
    private static JPanel panelConTabla(JPanel formulario, JTable tabla) {
        JPanel p = new JPanel(new BorderLayout(10,10)); p.setBorder(BorderFactory.createEmptyBorder(12,12,12,12));
        tabla.setAutoCreateRowSorter(true); tabla.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        p.add(formulario, BorderLayout.NORTH); p.add(new JScrollPane(tabla), BorderLayout.CENTER); return p;
    }
    private boolean confirmar(String texto) { return JOptionPane.showConfirmDialog(this, texto, "SpeedFast", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION; }
    private void mensaje(String texto) { JOptionPane.showMessageDialog(this, texto, "SpeedFast", JOptionPane.INFORMATION_MESSAGE); }
    private void error(String texto) { JOptionPane.showMessageDialog(this, texto, "SpeedFast - Error", JOptionPane.ERROR_MESSAGE); }
    private void errorSQL(SQLException e) {
        String texto = e.getMessage();
        if (e.getErrorCode() == 1451) texto = "No se puede eliminar porque el registro está asociado a una entrega.";
        error(texto);
    }
}
