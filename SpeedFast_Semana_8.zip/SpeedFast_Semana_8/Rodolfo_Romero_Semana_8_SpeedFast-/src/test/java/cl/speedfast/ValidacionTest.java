package cl.speedfast;
import cl.speedfast.modelo.*;
import org.junit.jupiter.api.Test;
import java.time.LocalDate;
import java.time.LocalTime;
import static org.junit.jupiter.api.Assertions.*;
class ValidacionTest {
    @Test void rechazaCamposVacios() {
        assertThrows(IllegalArgumentException.class, () -> new Repartidor("   "));
        assertThrows(IllegalArgumentException.class, () -> new Pedido(null, TipoPedido.COMIDA, EstadoPedido.PENDIENTE));
    }
    @Test void respetaLimitesDelModeloSQL() {
        assertEquals(100, new Repartidor("a".repeat(100)).getNombre().length());
        assertThrows(IllegalArgumentException.class, () -> new Repartidor("a".repeat(101)));
        assertThrows(IllegalArgumentException.class, () -> new Pedido("a".repeat(151), TipoPedido.EXPRESS, EstadoPedido.PENDIENTE));
    }
    @Test void conservaApostrofesYNormalizaBordes() {
        assertEquals("O'Higgins 120", new Pedido(" O'Higgins 120 ", TipoPedido.COMIDA, EstadoPedido.PENDIENTE).getDireccion());
    }
    @Test void exigeTipoEstadoYRelaciones() {
        assertThrows(IllegalArgumentException.class, () -> new Pedido("Calle 1", null, EstadoPedido.PENDIENTE));
        assertThrows(IllegalArgumentException.class, () -> new Pedido("Calle 1", TipoPedido.COMIDA, null));
        assertThrows(IllegalArgumentException.class, () -> new Entrega(0, 1, LocalDate.now(), LocalTime.NOON));
        assertThrows(IllegalArgumentException.class, () -> new Entrega(1, 0, LocalDate.now(), LocalTime.NOON));
        assertThrows(IllegalArgumentException.class, () -> new Entrega(1, 1, null, LocalTime.NOON));
    }
}
