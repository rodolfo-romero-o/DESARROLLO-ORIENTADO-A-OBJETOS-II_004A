package cl.speedfast.modelo;
import java.time.LocalDate;
import java.time.LocalTime;
public class Entrega {
    private final int idPedido;
    private final int idRepartidor;
    private final LocalDate fecha;
    private final LocalTime hora;
    public Entrega(int idPedido, int idRepartidor, LocalDate fecha, LocalTime hora) {
        this.idPedido = Validacion.id(idPedido, "Pedido");
        this.idRepartidor = Validacion.id(idRepartidor, "Repartidor");
        if (fecha == null || hora == null) throw new IllegalArgumentException("Fecha y hora son obligatorias.");
        this.fecha = fecha;
        this.hora = hora.withNano(0);
    }
    public int getIdPedido() { return idPedido; }
    public int getIdRepartidor() { return idRepartidor; }
    public LocalDate getFecha() { return fecha; }
    public LocalTime getHora() { return hora; }
}
