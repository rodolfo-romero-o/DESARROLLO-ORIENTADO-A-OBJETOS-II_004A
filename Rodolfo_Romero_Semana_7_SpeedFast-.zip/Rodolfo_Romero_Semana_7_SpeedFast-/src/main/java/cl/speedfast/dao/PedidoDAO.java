package cl.speedfast.dao;
import cl.speedfast.modelo.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PedidoDAO {

    public int guardar(Pedido dato) throws SQLException {
        if (dato == null) throw new IllegalArgumentException("No hay datos para guardar.");
        Connection cn = null;
        PreparedStatement ps = null;
        ResultSet claves = null;
        try {
            cn = ConexionBD.conectar();
            ps = cn.prepareStatement("INSERT INTO pedido (direccion, tipo, estado) VALUES (?, ?, ?)", Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, dato.getDireccion());
            ps.setString(2, dato.getTipo().name());
            ps.setString(3, dato.getEstado().name());
            if (ps.executeUpdate() != 1) throw new SQLException("No se insertó el registro.");
            claves = ps.getGeneratedKeys();
            if (!claves.next()) throw new SQLException("No se recibió el ID generado.");
            return claves.getInt(1);
        } catch (SQLException e) {
            throw new SQLException("No se pudo guardar pedido.", e.getSQLState(), e.getErrorCode(), e);
        } finally {
            ConexionBD.cerrar(claves);
            ConexionBD.cerrar(ps);
            ConexionBD.cerrar(cn);
        }
    }
        
    public List<Pedido> listarTodos() throws SQLException {
        List<Pedido> lista = new ArrayList<>();
        Connection cn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            cn = ConexionBD.conectar();
            ps = cn.prepareStatement("SELECT * FROM pedido ORDER BY id");
            rs = ps.executeQuery();
            while (rs.next()) lista.add(new Pedido(rs.getInt("id"), rs.getString("direccion"), TipoPedido.valueOf(rs.getString("tipo")), EstadoPedido.valueOf(rs.getString("estado"))));
            return lista;
        } catch (SQLException e) {
            throw new SQLException("No se pudieron consultar los registros de pedido.", e.getSQLState(), e.getErrorCode(), e);
        } finally {
            ConexionBD.cerrar(rs);
            ConexionBD.cerrar(ps);
            ConexionBD.cerrar(cn);
        }
    }

}
