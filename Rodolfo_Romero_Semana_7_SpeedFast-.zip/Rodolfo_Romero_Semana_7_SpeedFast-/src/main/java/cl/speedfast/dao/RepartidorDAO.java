package cl.speedfast.dao;
import cl.speedfast.modelo.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class RepartidorDAO {

    public int guardar(Repartidor dato) throws SQLException {
        if (dato == null) throw new IllegalArgumentException("No hay datos para guardar.");
        Connection cn = null;
        PreparedStatement ps = null;
        ResultSet claves = null;
        try {
            cn = ConexionBD.conectar();
            ps = cn.prepareStatement("INSERT INTO repartidor (nombre) VALUES (?)", Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, dato.getNombre());
            if (ps.executeUpdate() != 1) throw new SQLException("No se insertó el registro.");
            claves = ps.getGeneratedKeys();
            if (!claves.next()) throw new SQLException("No se recibió el ID generado.");
            return claves.getInt(1);
        } catch (SQLException e) {
            throw new SQLException("No se pudo guardar repartidor.", e.getSQLState(), e.getErrorCode(), e);
        } finally {
            ConexionBD.cerrar(claves);
            ConexionBD.cerrar(ps);
            ConexionBD.cerrar(cn);
        }
    }
        
    public List<Repartidor> listarTodos() throws SQLException {
        List<Repartidor> lista = new ArrayList<>();
        Connection cn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            cn = ConexionBD.conectar();
            ps = cn.prepareStatement("SELECT * FROM repartidor ORDER BY id");
            rs = ps.executeQuery();
            while (rs.next()) lista.add(new Repartidor(rs.getInt("id"), rs.getString("nombre")));
            return lista;
        } catch (SQLException e) {
            throw new SQLException("No se pudieron consultar los registros de repartidor.", e.getSQLState(), e.getErrorCode(), e);
        } finally {
            ConexionBD.cerrar(rs);
            ConexionBD.cerrar(ps);
            ConexionBD.cerrar(cn);
        }
    }

}
