package cl.speedfast.dao;
import cl.speedfast.modelo.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EntregaDAO {

    public int guardar(Entrega dato) throws SQLException {
        if (dato == null) throw new IllegalArgumentException("No hay datos para guardar.");
        Connection cn = null;
        PreparedStatement ps = null;
        ResultSet claves = null;
        try {
            cn = ConexionBD.conectar();
            ps = cn.prepareStatement("INSERT INTO entrega (id_pedido, id_repartidor, fecha, hora) VALUES (?, ?, ?, ?)", Statement.RETURN_GENERATED_KEYS);
            ps.setInt(1, dato.getIdPedido());
            ps.setInt(2, dato.getIdRepartidor());
            ps.setDate(3, java.sql.Date.valueOf(dato.getFecha()));
            ps.setTime(4, java.sql.Time.valueOf(dato.getHora()));
            if (ps.executeUpdate() != 1) throw new SQLException("No se insertó el registro.");
            claves = ps.getGeneratedKeys();
            if (!claves.next()) throw new SQLException("No se recibió el ID generado.");
            return claves.getInt(1);
        } catch (SQLException e) {
            throw new SQLException("No se pudo guardar entrega.", e.getSQLState(), e.getErrorCode(), e);
        } finally {
            ConexionBD.cerrar(claves);
            ConexionBD.cerrar(ps);
            ConexionBD.cerrar(cn);
        }
    }
        
}
