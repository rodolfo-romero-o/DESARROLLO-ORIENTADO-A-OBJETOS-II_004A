package cl.speedfast.vista;

import cl.speedfast.dao.*;
import cl.speedfast.modelo.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

public class VentanaPrincipal extends JFrame {
    private final PedidoDAO pedidos = new PedidoDAO();
    private final RepartidorDAO repartidores = new RepartidorDAO();
    private final EntregaDAO entregas = new EntregaDAO();
    private final JTextField direccion = new JTextField(28);
    private final JTextField nombre = new JTextField(28);
    private final JComboBox<TipoPedido> tipo = new JComboBox<>(TipoPedido.values());
    private final JComboBox<EstadoPedido> estado = new JComboBox<>(EstadoPedido.values());
    private final JComboBox<Pedido> pedidoEntrega = new JComboBox<>();
    private final JComboBox<Repartidor> repartidorEntrega = new JComboBox<>();
    private final JTextField fecha = new JTextField(LocalDate.now().toString());
    private final JTextField hora = new JTextField(LocalTime.now().withSecond(0).withNano(0).toString());
    private final DefaultTableModel tablaPedidos = modelo("ID", "Dirección", "Tipo", "Estado");
    private final DefaultTableModel tablaRepartidores = modelo("ID", "Nombre");
    private final JLabel mensaje = new JLabel("Cargue los datos con Actualizar para verificar la conexión.");
    private final List<JButton> botones = new ArrayList<>();

    public VentanaPrincipal() {
        super("SpeedFast | Semana 7 | Gestión de pedidos");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JTabbedPane pestanas = new JTabbedPane();
        JPanel formularioPedido = formulario();
        campo(formularioPedido, "Dirección (máx. 150)", direccion);
        campo(formularioPedido, "Tipo", tipo);
        campo(formularioPedido, "Estado", estado);
        formularioPedido.add(boton("Registrar pedido", this::guardarPedido));
        formularioPedido.add(boton("Actualizar pedidos", this::cargarPedidos));
        pestanas.addTab("Pedidos", panel(formularioPedido, new JTable(tablaPedidos)));

        JPanel formularioRepartidor = formulario();
        campo(formularioRepartidor, "Nombre (máx. 100)", nombre);
        formularioRepartidor.add(boton("Registrar repartidor", this::guardarRepartidor));
        formularioRepartidor.add(boton("Actualizar repartidores", this::cargarRepartidores));
        pestanas.addTab("Repartidores", panel(formularioRepartidor, new JTable(tablaRepartidores)));

        JPanel formularioEntrega = formulario();
        campo(formularioEntrega, "Pedido", pedidoEntrega);
        campo(formularioEntrega, "Repartidor", repartidorEntrega);
        campo(formularioEntrega, "Fecha (AAAA-MM-DD)", fecha);
        campo(formularioEntrega, "Hora (HH:mm o HH:mm:ss)", hora);
        formularioEntrega.add(boton("Cargar pedidos y repartidores", this::cargarOpciones));
        formularioEntrega.add(boton("Registrar entrega", this::guardarEntrega));
        JPanel panelEntrega = new JPanel(new BorderLayout(8, 8));
        panelEntrega.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));
        panelEntrega.add(formularioEntrega, BorderLayout.NORTH);
        panelEntrega.add(new JLabel("Registra una entrega o etapa; no modifica el estado del pedido."), BorderLayout.CENTER);
        pestanas.addTab("Entregas", panelEntrega);
        add(pestanas, BorderLayout.CENTER);
        mensaje.setBorder(BorderFactory.createEmptyBorder(10, 12, 10, 12));
        add(mensaje, BorderLayout.SOUTH);
        setSize(900, 560);
        setMinimumSize(new Dimension(780, 450));
        setLocationRelativeTo(null);
    }
    private static DefaultTableModel modelo(String... columnas) {
        return new DefaultTableModel(columnas, 0) {
            @Override public boolean isCellEditable(int fila, int columna) { return false; }
        };
    }
    private static JPanel formulario() { return new JPanel(new GridLayout(0, 2, 8, 8)); }
    private static void campo(JPanel panel, String etiqueta, JComponent entrada) {
        panel.add(new JLabel(etiqueta)); panel.add(entrada);
    }
    private static JPanel panel(JPanel formulario, JTable tabla) {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));
        panel.add(formulario, BorderLayout.NORTH);
        tabla.setFillsViewportHeight(true);
        tabla.setAutoCreateRowSorter(true);
        panel.add(new JScrollPane(tabla), BorderLayout.CENTER);
        return panel;
    }
    private JButton boton(String texto, Runnable accion) {
        JButton boton = new JButton(texto);
        boton.addActionListener(e -> {
            try { accion.run(); }
            catch (DateTimeParseException ex) { error("Fecha u hora inválida. Use AAAA-MM-DD y HH:mm, por ejemplo 2026-09-27 y 14:30."); }
            catch (IllegalArgumentException ex) { error(ex.getMessage()); }
        });
        botones.add(boton);
        return boton;
    }
    // SwingWorker mantiene la ventana activa durante el acceso a MySQL.
    private abstract class Tarea<T> extends SwingWorker<T, Void> {
        protected abstract void terminado(T resultado);
        @Override protected void done() {
            botones.forEach(b -> b.setEnabled(true));
            try { terminado(get()); }
            catch (InterruptedException e) { Thread.currentThread().interrupt(); error("Operación interrumpida."); }
            catch (ExecutionException e) { mostrarError(e.getCause()); }
        }
    }
    private void ejecutar(Tarea<?> tarea) {
        botones.forEach(b -> b.setEnabled(false));
        mensaje.setText("Consultando MySQL...");
        tarea.execute();
    }
    private void guardarPedido() {
        Pedido dato = new Pedido(direccion.getText(), (TipoPedido) tipo.getSelectedItem(), (EstadoPedido) estado.getSelectedItem());
        ejecutar(new Tarea<Integer>() {
            protected Integer doInBackground() throws SQLException { return pedidos.guardar(dato); }
            protected void terminado(Integer id) {
                direccion.setText("");
                JOptionPane.showMessageDialog(VentanaPrincipal.this, "Pedido guardado con ID " + id);
                cargarPedidos();
            }
        });
    }
    private void cargarPedidos() {
        ejecutar(new Tarea<List<Pedido>>() {
            protected List<Pedido> doInBackground() throws SQLException { return pedidos.listarTodos(); }
            protected void terminado(List<Pedido> lista) {
                tablaPedidos.setRowCount(0);
                pedidoEntrega.removeAllItems();
                for (Pedido p : lista) {
                    tablaPedidos.addRow(new Object[]{p.getId(), p.getDireccion(), p.getTipo(), p.getEstado()});
                    pedidoEntrega.addItem(p);
                }
                mensaje.setText(lista.size() + " pedido(s) consultado(s) en MySQL.");
            }
        });
    }
    private void guardarRepartidor() {
        Repartidor dato = new Repartidor(nombre.getText());
        ejecutar(new Tarea<Integer>() {
            protected Integer doInBackground() throws SQLException { return repartidores.guardar(dato); }
            protected void terminado(Integer id) {
                nombre.setText("");
                JOptionPane.showMessageDialog(VentanaPrincipal.this, "Repartidor guardado con ID " + id);
                cargarRepartidores();
            }
        });
    }
    private void cargarRepartidores() {
        ejecutar(new Tarea<List<Repartidor>>() {
            protected List<Repartidor> doInBackground() throws SQLException { return repartidores.listarTodos(); }
            protected void terminado(List<Repartidor> lista) {
                tablaRepartidores.setRowCount(0);
                repartidorEntrega.removeAllItems();
                for (Repartidor r : lista) {
                    tablaRepartidores.addRow(new Object[]{r.getId(), r.getNombre()});
                    repartidorEntrega.addItem(r);
                }
                mensaje.setText(lista.size() + " repartidor(es) consultado(s) en MySQL.");
            }
        });
    }
    private void cargarOpciones() {
        ejecutar(new Tarea<Void>() {
            private List<Pedido> listaPedidos;
            private List<Repartidor> listaRepartidores;
            protected Void doInBackground() throws SQLException {
                listaPedidos = pedidos.listarTodos(); listaRepartidores = repartidores.listarTodos(); return null;
            }
            protected void terminado(Void nada) {
                pedidoEntrega.removeAllItems(); repartidorEntrega.removeAllItems();
                listaPedidos.forEach(pedidoEntrega::addItem);
                listaRepartidores.forEach(repartidorEntrega::addItem);
                mensaje.setText("Opciones actualizadas. Si faltan datos, registre primero un pedido y un repartidor.");
            }
        });
    }
    private void guardarEntrega() {
        Pedido p = (Pedido) pedidoEntrega.getSelectedItem();
        Repartidor r = (Repartidor) repartidorEntrega.getSelectedItem();
        if (p == null || r == null) throw new IllegalArgumentException("Cargue y seleccione un pedido y un repartidor.");
        Entrega dato = new Entrega(p.getId(), r.getId(), LocalDate.parse(fecha.getText().trim()), LocalTime.parse(hora.getText().trim()));
        ejecutar(new Tarea<Integer>() {
            protected Integer doInBackground() throws SQLException { return entregas.guardar(dato); }
            protected void terminado(Integer id) {
                mensaje.setText("Entrega registrada en MySQL con ID " + id);
                JOptionPane.showMessageDialog(VentanaPrincipal.this, "Entrega guardada con ID " + id);
            }
        });
    }
    private void mostrarError(Throwable causa) {
        if (causa instanceof SQLException sql) {
            String detalle = "Revise config/db.properties, el servicio MySQL y la ejecución del script SQL.";
            if (sql.getErrorCode() == 1452) detalle = "El pedido o repartidor ya no existe. Actualice las opciones.";
            if (sql.getErrorCode() == 1045) detalle = "MySQL rechazó el usuario o la contraseña. Corrija config/db.properties.";
            if (sql.getErrorCode() == 1049 || sql.getErrorCode() == 1146) detalle = "Falta la base de datos o una tabla. Ejecute sql/01_crear_base.sql.";
            error(sql.getMessage() + "\n" + detalle);
        } else error("No se pudo completar la operación: " + causa.getMessage());
    }
    private void error(String texto) {
        mensaje.setText("Operación no completada. Revise el mensaje de error.");
        JOptionPane.showMessageDialog(this, texto, "SpeedFast", JOptionPane.ERROR_MESSAGE);
    }
}
