package vista;

import modelo.ControladorPedidos;
import javax.swing.*;
import java.awt.*;
import java.util.concurrent.ExecutionException;

public class VentanaPrincipal extends JFrame {
    private final ControladorPedidos controlador;
    private final JButton iniciar = new JButton("Asignar repartidor / Iniciar entrega");
    private final JLabel estado = new JLabel("Registra pedidos para comenzar.", SwingConstants.CENTER);
    private VentanaRegistroPedido registro;
    private VentanaListaPedidos listado;

    public VentanaPrincipal() { this(new ControladorPedidos()); }

    public VentanaPrincipal(ControladorPedidos controlador) {
        super("SpeedFast - Gestión de entregas");
        this.controlador = controlador;
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        JPanel contenido = new JPanel(new BorderLayout(16, 20));
        contenido.setBorder(BorderFactory.createEmptyBorder(24, 30, 24, 30));
        JLabel titulo = new JLabel("SPEEDFAST", SwingConstants.CENTER);
        titulo.setFont(titulo.getFont().deriveFont(Font.BOLD, 26f));
        contenido.add(titulo, BorderLayout.NORTH);
        JPanel botones = new JPanel(new GridLayout(3, 1, 10, 12));
        JButton registrar = new JButton("Registrar pedido");
        JButton listar = new JButton("Listar pedidos");
        botones.add(registrar); botones.add(listar); botones.add(iniciar);
        contenido.add(botones, BorderLayout.CENTER);
        contenido.add(estado, BorderLayout.SOUTH);
        registrar.addActionListener(e -> {
            if (registro == null || !registro.isDisplayable()) registro = new VentanaRegistroPedido(controlador);
            registro.setVisible(true); registro.toFront();
        });
        listar.addActionListener(e -> mostrarListado());
        iniciar.addActionListener(e -> iniciarEntregas());
        add(contenido);
        setSize(580, 340);
        setMinimumSize(new Dimension(580, 340));
        setLocationRelativeTo(null);
    }

    private void mostrarListado() {
        if (listado == null || !listado.isDisplayable()) listado = new VentanaListaPedidos(controlador);
        listado.refrescarTabla(); listado.setVisible(true); listado.toFront();
    }

    private void iniciarEntregas() {
        iniciar.setEnabled(false);
        estado.setText("Juan, Camila y Pedro están procesando los pedidos...");
        mostrarListado();
        new SwingWorker<Integer, Void>() {
            @Override protected Integer doInBackground() throws Exception {
                return controlador.procesarPendientes();
            }
            @Override protected void done() {
                try {
                    int cantidad = get();
                    estado.setText(cantidad == 0 ? "No hay pedidos pendientes." : "Lote finalizado: " + cantidad + " pedidos entregados.");
                    if (cantidad == 0) JOptionPane.showMessageDialog(VentanaPrincipal.this, "Registra un pedido pendiente para iniciar una entrega.");
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    estado.setText("La espera de entregas fue interrumpida.");
                } catch (ExecutionException e) {
                    estado.setText("No se pudo completar el lote.");
                    JOptionPane.showMessageDialog(VentanaPrincipal.this, e.getCause().getMessage(), "Error de entrega", JOptionPane.ERROR_MESSAGE);
                } finally {
                    iniciar.setEnabled(true);
                    if (listado != null && listado.isDisplayable()) listado.refrescarTabla();
                }
            }
        }.execute();
    }
}
