package vista;

import modelo.ControladorPedidos;
import modelo.Pedido;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class VentanaListaPedidos extends JFrame {
    private final ControladorPedidos controlador;
    private final DefaultTableModel modeloTabla = new DefaultTableModel(
            new String[] {"ID", "Dirección", "Tipo", "Estado", "Repartidor"}, 0) {
        @Override public boolean isCellEditable(int fila, int columna) { return false; }
        @Override public Class<?> getColumnClass(int columna) { return columna == 0 ? Integer.class : Object.class; }
    };
    private final JLabel resumen = new JLabel();
    private final Timer refresco;

    public VentanaListaPedidos(ControladorPedidos controlador) {
        super("SpeedFast - Listar pedidos");
        this.controlador = controlador;
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        JTable tabla = new JTable(modeloTabla);
        tabla.setRowHeight(26);
        tabla.setAutoCreateRowSorter(true);
        tabla.getColumnModel().getColumn(1).setPreferredWidth(260);
        JPanel contenido = new JPanel(new BorderLayout(10, 10));
        contenido.setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));
        contenido.add(new JScrollPane(tabla), BorderLayout.CENTER);
        JPanel pie = new JPanel(new BorderLayout());
        JButton actualizar = new JButton("Refrescar");
        actualizar.addActionListener(e -> refrescarTabla());
        pie.add(resumen, BorderLayout.CENTER); pie.add(actualizar, BorderLayout.EAST);
        contenido.add(pie, BorderLayout.SOUTH);
        add(contenido);
        // Timer se ejecuta en el hilo de Swing, por lo que la tabla se actualiza de forma segura.
        refresco = new Timer(300, e -> refrescarTabla());
        addWindowListener(new WindowAdapter() {
            @Override public void windowOpened(WindowEvent e) { refresco.start(); }
            @Override public void windowClosed(WindowEvent e) { refresco.stop(); }
        });
        refrescarTabla();
        setSize(850, 400);
        setMinimumSize(new Dimension(680, 300));
        setLocationRelativeTo(null);
    }

    public void refrescarTabla() {
        modeloTabla.setRowCount(0);
        for (Pedido pedido : controlador.obtenerPedidos()) modeloTabla.addRow(pedido.obtenerFila());
        resumen.setText(modeloTabla.getRowCount() + " pedidos | Actualización automática");
    }
}
