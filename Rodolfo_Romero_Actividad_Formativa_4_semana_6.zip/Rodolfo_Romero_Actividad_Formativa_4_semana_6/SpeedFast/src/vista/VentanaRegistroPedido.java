package vista;

import modelo.ControladorPedidos;
import javax.swing.*;
import java.awt.*;

public class VentanaRegistroPedido extends JFrame {
    private final JTextField campoId = new JTextField(20);
    private final JTextField campoDireccion = new JTextField(20);
    private final JComboBox<String> campoTipo = new JComboBox<>(new String[] {"comida", "encomienda", "express"});

    public VentanaRegistroPedido(ControladorPedidos controlador) {
        super("SpeedFast - Registrar pedido");
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        JPanel formulario = new JPanel(new GridLayout(0, 2, 10, 12));
        formulario.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        formulario.add(new JLabel("ID (entero positivo):")); formulario.add(campoId);
        formulario.add(new JLabel("Dirección:")); formulario.add(campoDireccion);
        formulario.add(new JLabel("Tipo:")); formulario.add(campoTipo);
        JButton guardar = new JButton("Guardar");
        JButton cerrar = new JButton("Cerrar");
        formulario.add(guardar); formulario.add(cerrar);
        guardar.addActionListener(e -> {
            try {
                controlador.registrarPedido(campoId.getText(), campoDireccion.getText(), (String) campoTipo.getSelectedItem());
                JOptionPane.showMessageDialog(this, "Pedido registrado correctamente.", "Registro exitoso", JOptionPane.INFORMATION_MESSAGE);
                campoId.setText(""); campoDireccion.setText(""); campoTipo.setSelectedIndex(0);
                campoId.requestFocusInWindow();
            } catch (IllegalArgumentException ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Revisa los datos", JOptionPane.WARNING_MESSAGE);
            }
        });
        cerrar.addActionListener(e -> dispose());
        add(formulario);
        getRootPane().setDefaultButton(guardar);
        pack();
        setMinimumSize(getSize());
        setLocationRelativeTo(null);
    }
}
