package modelo;

import java.util.ArrayDeque;
import java.util.List;
import java.util.Queue;

public class ZonaDeCarga {
    private final Queue<Pedido> pedidos = new ArrayDeque<>();

    public ZonaDeCarga(List<Pedido> pendientes) { pedidos.addAll(pendientes); }


    public synchronized Pedido retirarPedido(String repartidor) {
        Pedido pedido = pedidos.poll();
        if (pedido != null) pedido.iniciarReparto(repartidor);
        return pedido;
    }
}
