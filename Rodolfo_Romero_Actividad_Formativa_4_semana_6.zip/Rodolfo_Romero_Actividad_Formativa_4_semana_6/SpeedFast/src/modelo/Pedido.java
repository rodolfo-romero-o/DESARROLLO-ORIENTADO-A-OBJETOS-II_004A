package modelo;

public abstract class Pedido {
    private final int idPedido;
    private final String direccionEntrega;
    private final double distanciaKm;
    private String repartidor = "Sin asignar";
    private EstadoPedido estado = EstadoPedido.PENDIENTE;

    public Pedido(int idPedido, String direccionEntrega, double distanciaKm) {
        if (idPedido <= 0) throw new IllegalArgumentException("El ID debe ser un entero positivo.");
        if (direccionEntrega == null || direccionEntrega.trim().isEmpty()) {
            throw new IllegalArgumentException("La dirección es obligatoria.");
        }
        if (!Double.isFinite(distanciaKm) || distanciaKm < 0) {
            throw new IllegalArgumentException("La distancia no puede ser negativa.");
        }
        this.idPedido = idPedido;
        this.direccionEntrega = direccionEntrega.trim();
        this.distanciaKm = distanciaKm;
    }

    public abstract int calcularTiempoEntrega();

    public String getTipo() {
        if (this instanceof PedidoComida) return "comida";
        if (this instanceof PedidoEncomienda) return "encomienda";
        return "express";
    }

    // semana anterior
    public void mostrarResumen() {
        System.out.println("Pedido #" + idPedido + " - " + direccionEntrega + " - " + getEstado());
    }
    public void asignarRepartidor() { System.out.println("Buscando repartidor disponible..."); }
    public synchronized void asignarRepartidor(String nombre) { repartidor = nombre; }
    public synchronized void setRepartidor(String nombre) { asignarRepartidor(nombre); }
    public int getIdPedido() { return idPedido; }
    public String getDireccionEntrega() { return direccionEntrega; }
    public double getDistancia() { return distanciaKm; }
    public double getDistanciaKm() { return distanciaKm; }
    public synchronized String getRepartidor() { return repartidor; }
    public synchronized EstadoPedido getEstado() { return estado; }

    synchronized void iniciarReparto(String nombre) {
        if (estado != EstadoPedido.PENDIENTE) throw new IllegalStateException("El pedido ya fue retirado.");
        repartidor = nombre;
        estado = EstadoPedido.EN_REPARTO;
    }

    synchronized void completarEntrega() {
        if (estado != EstadoPedido.EN_REPARTO) throw new IllegalStateException("El pedido no está en reparto.");
        estado = EstadoPedido.ENTREGADO;
    }

    synchronized void devolverAPendientes() {
        estado = EstadoPedido.PENDIENTE;
        repartidor = "Sin asignar";
    }


    public synchronized Object[] obtenerFila() {
        return new Object[] {idPedido, direccionEntrega, getTipo(), estado, repartidor};
    }
}
