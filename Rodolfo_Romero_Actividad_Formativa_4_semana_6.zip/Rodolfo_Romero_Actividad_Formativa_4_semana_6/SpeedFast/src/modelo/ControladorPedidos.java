package modelo;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;

public class ControladorPedidos {
    private final List<Pedido> pedidos = new ArrayList<>();
    private final ControladorDeEnvios historial = new ControladorDeEnvios();
    private boolean entregando;

    public synchronized Pedido registrarPedido(String textoId, String direccion, String tipo) {
        int id;
        try {
            id = Integer.parseInt(textoId == null ? "" : textoId.trim());
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("El ID debe ser un número entero positivo dentro del rango permitido.");
        }
        if (id <= 0) throw new IllegalArgumentException("El ID debe ser mayor que cero.");
        if (existePedido(id)) throw new IllegalArgumentException("Ya existe un pedido con ese ID.");
        Pedido pedido;
        // ID, dirección y tipo
        if ("comida".equals(tipo)) pedido = new PedidoComida(id, direccion, 1);
        else if ("encomienda".equals(tipo)) pedido = new PedidoEncomienda(id, direccion, 1);
        else if ("express".equals(tipo)) pedido = new PedidoExpress(id, direccion, 1);
        else throw new IllegalArgumentException("Selecciona un tipo de pedido válido.");
        pedidos.add(pedido);
        return pedido;
    }

    public synchronized boolean existePedido(int id) {
        for (Pedido pedido : pedidos) if (pedido.getIdPedido() == id) return true;
        return false;
    }

    public synchronized List<Pedido> obtenerPedidos() { return new ArrayList<>(pedidos); }
    public synchronized boolean isEntregando() { return entregando; }
    public List<String> obtenerHistorial() { return historial.obtenerHistorial(); }

    /** Espera al lote completo. Llamar desde un hilo de trabajo, nunca desde el hilo de Swing. */
    public int procesarPendientes() throws InterruptedException, ExecutionException {
        List<Pedido> pendientes = new ArrayList<>();
        synchronized (this) {
            if (entregando) throw new IllegalStateException("Ya hay entregas en curso.");
            for (Pedido pedido : pedidos) {
                if (pedido.getEstado() == EstadoPedido.PENDIENTE) pendientes.add(pedido);
            }
            if (pendientes.isEmpty()) return 0;
            entregando = true;
        }
        ExecutorService ejecutor = Executors.newFixedThreadPool(3);
        try {
            ZonaDeCarga zona = new ZonaDeCarga(pendientes);
            List<Future<?>> tareas = new ArrayList<>();
            for (String nombre : new String[] {"Juan", "Camila", "Pedro"}) {
                tareas.add(ejecutor.submit(new Repartidor(nombre, zona, historial)));
            }
            for (Future<?> tarea : tareas) tarea.get();
            System.out.println("Todos los pedidos han sido entregados correctamente");
            return pendientes.size();
        } finally {
            ejecutor.shutdownNow();
            // No se permite otro pedido hasta que terminen los anteriores.
            boolean interrumpido = false;
            while (!ejecutor.isTerminated()) {
                try { ejecutor.awaitTermination(1, TimeUnit.SECONDS); }
                catch (InterruptedException e) { interrumpido = true; }
            }
            synchronized (this) { entregando = false; }
            if (interrumpido) Thread.currentThread().interrupt();
        }
    }
}
