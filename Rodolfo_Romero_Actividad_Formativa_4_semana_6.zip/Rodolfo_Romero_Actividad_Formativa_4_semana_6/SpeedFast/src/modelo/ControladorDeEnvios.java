package modelo;

import java.util.ArrayList;
import java.util.List;

public class ControladorDeEnvios implements Rastreable {
    private final List<String> historial = new ArrayList<>();

    public synchronized void registrarEntrega(Pedido pedido) {
        historial.add(pedido.getClass().getSimpleName() + " #" + pedido.getIdPedido()
                + " - entregado por " + pedido.getRepartidor());
    }

    public synchronized List<String> obtenerHistorial() { return new ArrayList<>(historial); }

    @Override
    public synchronized void verHistorial() {
        System.out.println("\nHistorial:");
        if (historial.isEmpty()) System.out.println("No existen entregas registradas.");
        for (String entrega : historial) System.out.println("- " + entrega);
    }
}
