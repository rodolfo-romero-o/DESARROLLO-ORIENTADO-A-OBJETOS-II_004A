package modelo;

public class Repartidor implements Runnable {
    private final String nombre;
    private final ZonaDeCarga zona;
    private final ControladorDeEnvios historial;

    public Repartidor(String nombre, ZonaDeCarga zona, ControladorDeEnvios historial) {
        this.nombre = nombre;
        this.zona = zona;
        this.historial = historial;
    }

    @Override
    public void run() {
        while (!Thread.currentThread().isInterrupted()) {
            Pedido pedido = zona.retirarPedido(nombre);
            if (pedido == null) return;
            try {
                System.out.println(nombre + " retira pedido #" + pedido.getIdPedido());
                // Simulación breve; el tiempo estimado original está expresado en minutos.
                Thread.sleep(1000L + (pedido instanceof PedidoExpress ? 0 : 500));
                pedido.completarEntrega();
                historial.registrarEntrega(pedido);
                System.out.println(nombre + " entrega pedido #" + pedido.getIdPedido());
            } catch (InterruptedException e) {
                pedido.devolverAPendientes();
                Thread.currentThread().interrupt();
                return;
            }
        }
    }
}
