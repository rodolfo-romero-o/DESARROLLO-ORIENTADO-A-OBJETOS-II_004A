public class Main {

    public static void main(String[] args) {

        // Objetos utilizando polimorfismo
        Pedido pedido1 = new PedidoComida(
                1,
                "Av. Ejercito libertador 1468",
                "Comida"
        );

        Pedido pedido2 = new PedidoEncomienda(
                2,
                "Av. Vicuña Mackena 3698",
                "Encomienda"
        );

        Pedido pedido3 = new PedidoExpress(
                3,
                "Av. Camilo Henriquez 3296 ",
                "Express"
        );

        // PEDIDO DE COMIDA
        pedido1.asignarRepartidor();
        pedido1.asignarRepartidor("Juan Perez");

        System.out.println("-----------------------------");

        // PEDIDO DE ENCOMIENDA
        pedido2.asignarRepartidor();
        pedido2.asignarRepartidor("Juana Perez");

        System.out.println("-----------------------------");

        // PEDIDO EXPRESS
        pedido3.asignarRepartidor();
        pedido3.asignarRepartidor("Pedro Perez");
    }
}