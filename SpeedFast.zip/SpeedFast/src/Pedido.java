public class Pedido {

    private int idPedido;
    private String direccionEntrega;
    private String tipoPedido;

    // Constructor
    public Pedido(int idPedido, String direccionEntrega, String tipoPedido) {
        this.idPedido = idPedido;
        this.direccionEntrega = direccionEntrega;
        this.tipoPedido = tipoPedido;
    }

    // Método genérico
    public void asignarRepartidor() {
        System.out.println("Asignando repartidor...");
    }

    // Método sobrecargado
    public void asignarRepartidor(String nombreRepartidor) {
        System.out.println("Pedido asignado a: " + nombreRepartidor);
    }

    // Getters
    public int getIdPedido() {
        return idPedido;
    }

    public String getDireccionEntrega() {
        return direccionEntrega;
    }

    public String getTipoPedido() {
        return tipoPedido;
    }

    // Setters
    public void setIdPedido(int idPedido) {
        this.idPedido = idPedido;
    }

    public void setDireccionEntrega(String direccionEntrega) {
        this.direccionEntrega = direccionEntrega;
    }

    public void setTipoPedido(String tipoPedido) {
        this.tipoPedido = tipoPedido;
    }
}