# SpeedFast - Semana 4

Proyecto de Desarrollo Orientado a Objetos II.

## Funcionalidades

- Clase abstracta `Pedido`.
- Subclases `PedidoComida`, `PedidoEncomienda` y `PedidoExpress`.
- Interfaces `Despachable`, `Cancelable` y `Rastreable`.
- Clase `Repartidor` que implementa `Runnable`.
- Ejecución concurrente de tres repartidores mediante `ExecutorService`.
- Cada repartidor procesa dos pedidos de forma secuencial.
- Uso de `Thread.sleep()` con tiempos aleatorios para simular entregas.
- Manejo de `InterruptedException`.
- Historial de entregas protegido con métodos `synchronized`.

## Ejecución

Abrir el proyecto en IntelliJ IDEA y ejecutar la clase `Main`.
