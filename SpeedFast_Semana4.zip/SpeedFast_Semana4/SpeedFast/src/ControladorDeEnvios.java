import java.util.ArrayList;

public class ControladorDeEnvios implements Rastreable {

    private ArrayList<String> historial;

    public ControladorDeEnvios() {
        historial = new ArrayList<>();
    }

    // synchronized evita que varios hilos modifiquen el historial al mismo tiempo.
    public synchronized void registrarEntrega(Pedido pedido) {

        String registro =
                pedido.getClass().getSimpleName()
                        + " #" + pedido.getIdPedido()
                        + " - entregado por "
                        + pedido.getRepartidor();

        historial.add(registro);
    }

    @Override
    public synchronized void verHistorial() {

        System.out.println("\n===== HISTORIAL DE ENTREGAS =====");

        if (historial.isEmpty()) {
            System.out.println("No existen entregas registradas.");
        } else {
            for (String entrega : historial) {
                System.out.println("- " + entrega);
            }
        }
    }
}
