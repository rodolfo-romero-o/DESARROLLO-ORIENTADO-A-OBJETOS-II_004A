import java.util.ArrayList;
import java.util.Random;

public class Repartidor implements Runnable {

    private String nombre;
    private ArrayList<Pedido> pedidosAsignados;
    private ControladorDeEnvios controlador;

    public Repartidor(String nombre, ControladorDeEnvios controlador) {
        this.nombre = nombre;
        this.controlador = controlador;
        this.pedidosAsignados = new ArrayList<>();
    }

    public void agregarPedido(Pedido pedido) {
        pedidosAsignados.add(pedido);
    }

    @Override
    public void run() {

        Random random = new Random();

        System.out.println("[Repartidor: " + nombre + "] Inicia su jornada.");

        for (Pedido pedido : pedidosAsignados) {

            try {
                if (pedido.isCancelado()) {
                    System.out.println("[Repartidor: " + nombre + "] Pedido #"
                            + pedido.getIdPedido() + " está cancelado.");
                    continue;
                }

                pedido.setRepartidor(nombre);

                System.out.println("[Repartidor: " + nombre + "] Entregando "
                        + pedido.getClass().getSimpleName()
                        + " #" + pedido.getIdPedido() + "...");

                System.out.println("[Repartidor: " + nombre + "] Destino: "
                        + pedido.getDireccionEntrega());

                // Pausa aleatoria entre 1 y 3 segundos para simular la entrega.
                int tiempoEspera = random.nextInt(2000) + 1000;
                Thread.sleep(tiempoEspera);

                if (pedido instanceof Despachable) {
                    ((Despachable) pedido).despachar();
                }

                controlador.registrarEntrega(pedido);

                System.out.println("[Repartidor: " + nombre + "] Pedido #"
                        + pedido.getIdPedido() + " entregado.");

            } catch (InterruptedException e) {
                System.out.println("[Repartidor: " + nombre + "] La entrega fue interrumpida.");
                Thread.currentThread().interrupt();
                return;
            }
        }

        System.out.println("[Repartidor: " + nombre + "] Terminó todas sus entregas.");
    }
}
