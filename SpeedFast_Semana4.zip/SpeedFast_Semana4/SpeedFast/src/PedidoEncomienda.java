public class PedidoEncomienda extends Pedido
        implements Despachable, Cancelable {

    public PedidoEncomienda(int idPedido, String direccionEntrega, double distanciaKm) {
        super(idPedido, direccionEntrega, distanciaKm);
    }

    @Override
    public void asignarRepartidor() {
        System.out.println("[Pedido Encomienda]");
        System.out.println("Validando peso y embalaje...");
        setRepartidor("Daniela Tapia");
        System.out.println("Repartidor asignado: " + getRepartidor());
    }

    @Override
    public int calcularTiempoEntrega() {
        return (int) (getDistanciaKm() * 4 + 2);
    }

    @Override
    public void despachar() {
        System.out.println("Pedido de encomienda #" + getIdPedido() + " despachado correctamente.");
    }

    @Override
    public void cancelar() {
        marcarCancelado();
        System.out.println("Pedido de encomienda #" + getIdPedido() + " cancelado.");
    }
}
