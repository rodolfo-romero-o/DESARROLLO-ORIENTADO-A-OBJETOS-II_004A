public abstract class Pedido {

    private int idPedido;
    private String direccionEntrega;
    private double distanciaKm;
    private String repartidor;
    private boolean cancelado;

    public Pedido(int idPedido, String direccionEntrega, double distanciaKm) {
        this.idPedido = idPedido;
        this.direccionEntrega = direccionEntrega;
        this.distanciaKm = distanciaKm;
        this.repartidor = "Sin asignar";
        this.cancelado = false;
    }

    public void mostrarResumen() {
        System.out.println("Pedido #" + idPedido);
        System.out.println("Dirección: " + direccionEntrega);
        System.out.println("Distancia: " + distanciaKm + " km");
        System.out.println("Repartidor asignado: " + repartidor);
        System.out.println("Tiempo estimado: " + calcularTiempoEntrega() + " minutos");
    }

    public void asignarRepartidor() {
        System.out.println("Buscando repartidor disponible...");
    }

    public void asignarRepartidor(String nombre) {
        repartidor = nombre;
        System.out.println("Pedido asignado a " + nombre);
    }

    public abstract int calcularTiempoEntrega();

    public int getIdPedido() {
        return idPedido;
    }

    public String getDireccionEntrega() {
        return direccionEntrega;
    }

    public double getDistanciaKm() {
        return distanciaKm;
    }

    // Se conserva ya que no descubri porque sin ella da error.
    public double getDistancia() {
        return distanciaKm;
    }

    public String getRepartidor() {
        return repartidor;
    }

    public void setRepartidor(String repartidor) {
        this.repartidor = repartidor;
    }

    public boolean isCancelado() {
        return cancelado;
    }

    protected void marcarCancelado() {
        this.cancelado = true;
    }
}
