public class PedidoComida extends Pedido
        implements Despachable, Cancelable {

    public PedidoComida(int idPedido, String direccionEntrega, double distanciaKm) {
        super(idPedido, direccionEntrega, distanciaKm);
    }

    @Override
    public void asignarRepartidor() {
        System.out.println("[Pedido Comida]");
        System.out.println("Buscando repartidor con mochila térmica...");
        setRepartidor("Luis Díaz");
        System.out.println("Repartidor asignado: " + getRepartidor());
    }

    @Override
    public int calcularTiempoEntrega() {
        return (int) (getDistanciaKm() * 4);
    }

    @Override
    public void despachar() {
        System.out.println("Pedido de comida #" + getIdPedido() + " despachado correctamente.");
    }

    @Override
    public void cancelar() {
        marcarCancelado();
        System.out.println("Pedido de comida #" + getIdPedido() + " cancelado.");
    }
}
