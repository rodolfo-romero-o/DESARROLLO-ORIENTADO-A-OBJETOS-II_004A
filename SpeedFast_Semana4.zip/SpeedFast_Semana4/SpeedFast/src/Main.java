import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class Main {

    public static void main(String[] args) {

        ControladorDeEnvios controlador = new ControladorDeEnvios();

        // Se crean seis pedidos para asignar dos a cada repartidor.
        PedidoComida pedido1 = new PedidoComida(
                101, "Av. Camilo Henríquez 123", 5);

        PedidoEncomienda pedido2 = new PedidoEncomienda(
                102, "Av. Santa Rosa 567", 7);

        PedidoExpress pedido3 = new PedidoExpress(
                103, "Av. Vicuña Mackenna 900", 4);

        PedidoComida pedido4 = new PedidoComida(
                104, "Av. La Florida 1500", 6);

        PedidoEncomienda pedido5 = new PedidoEncomienda(
                105, "Independencia 3200", 8);

        PedidoExpress pedido6 = new PedidoExpress(
                106, "Av. San Carlos 1200", 3);

        // Se crean tres repartidores.
        Repartidor camila = new Repartidor("Camila", controlador);
        Repartidor luis = new Repartidor("Luis", controlador);
        Repartidor daniela = new Repartidor("Daniela", controlador);

        // Cada repartidor recibe dos pedidos.
        camila.agregarPedido(pedido1);
        camila.agregarPedido(pedido2);

        luis.agregarPedido(pedido3);
        luis.agregarPedido(pedido4);

        daniela.agregarPedido(pedido5);
        daniela.agregarPedido(pedido6);

        System.out.println("===== SPEEDFAST - SEMANA 4 =====");
        System.out.println("Ejecutando entregas en paralelo...\n");

        // ExecutorService permite ejecutar los tres repartidores en paralelo.
        ExecutorService executor = Executors.newFixedThreadPool(3);

        executor.execute(camila);
        executor.execute(luis);
        executor.execute(daniela);

        // Se indica que no se recibirán nuevas tareas.
        executor.shutdown();

        try {
            // Se espera hasta que todos los repartidores terminen.
            boolean terminaron = executor.awaitTermination(1, TimeUnit.MINUTES);

            if (terminaron) {
                System.out.println("\nTodas las entregas finalizaron correctamente.");
            } else {
                System.out.println("\nEl tiempo de espera terminó antes de completar las entregas.");
                executor.shutdownNow();
            }

        } catch (InterruptedException e) {
            System.out.println("La ejecución principal fue interrumpida.");
            executor.shutdownNow();
            Thread.currentThread().interrupt();
        }

        controlador.verHistorial();
    }
}
