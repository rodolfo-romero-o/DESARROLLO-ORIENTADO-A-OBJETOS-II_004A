public class PedidoExpress extends Pedido
        implements Despachable, Cancelable {

    public PedidoExpress(int idPedido, String direccionEntrega, double distanciaKm) {
        super(idPedido, direccionEntrega, distanciaKm);
    }

    @Override
    public void asignarRepartidor() {
        System.out.println("[Pedido Express]");
        System.out.println("Buscando repartidor más cercano...");
        setRepartidor("Camila Soto");
        System.out.println("Repartidor asignado: " + getRepartidor());
    }

    @Override
    public int calcularTiempoEntrega() {
        return (int) (getDistanciaKm() * 3);
    }

    @Override
    public void despachar() {
        System.out.println("Pedido express #" + getIdPedido() + " despachado correctamente.");
    }

    @Override
    public void cancelar() {
        marcarCancelado();
        System.out.println("Pedido express #" + getIdPedido() + " cancelado exitosamente.");
    }
}
