import java.util.Random;

public class Repartidor implements Runnable {

    private final String nombre;
    private final ZonaDeCarga zonaDeCarga;
    private final ControladorDeEnvios controlador;

    public Repartidor(String nombre, ZonaDeCarga zonaDeCarga,
                      ControladorDeEnvios controlador) {
        this.nombre = nombre;
        this.zonaDeCarga = zonaDeCarga;
        this.controlador = controlador;
    }

    @Override
    public void run() {

        Random random = new Random();

        while (true) {
            // retirarPedido().
            Pedido pedido = zonaDeCarga.retirarPedido();

            if (pedido == null) {
                break;
            }

            try {
                pedido.setRepartidor(nombre);
                pedido.setEstado(EstadoPedido.EN_REPARTO);

                System.out.println("[Repartidor - " + nombre + "] Retirando pedido #"
                        + pedido.getIdPedido() + "...");
                System.out.println("[Repartidor - " + nombre + "] Estado: "
                        + pedido.getEstado());
                System.out.println("[Repartidor - " + nombre + "] Entregando pedido #"
                        + pedido.getIdPedido() + "...");

                // tiempo de entrega.
                int tiempoEspera = random.nextInt(2000) + 1000;
                Thread.sleep(tiempoEspera);

                if (pedido instanceof Despachable) {
                    ((Despachable) pedido).despachar();
                }

                pedido.setEstado(EstadoPedido.ENTREGADO);
                controlador.registrarEntrega(pedido);

                System.out.println("[Repartidor - " + nombre + "] Estado: "
                        + pedido.getEstado());

            } catch (InterruptedException e) {
                System.out.println("[Repartidor - " + nombre
                        + "] La entrega fue interrumpida.");
                Thread.currentThread().interrupt();
                return;
            }
        }

        System.out.println("[Repartidor - " + nombre
                + "] No quedan pedidos en la zona de carga.");
    }
}
