import java.util.ArrayList;
import java.util.List;

public class ZonaDeCarga {

    private final List<Pedido> pedidosPendientes;

    public ZonaDeCarga() {
        pedidosPendientes = new ArrayList<>();
        System.out.println("[Zona de carga inicializada]");
    }

    // synchronized.
    public synchronized void agregarPedido(Pedido pedido) {
        pedidosPendientes.add(pedido);
        System.out.println("Pedido #" + pedido.getIdPedido()
                + " agregado. Destino: " + pedido.getDireccionEntrega());
    }

    // synchronized repartidores.
    public synchronized Pedido retirarPedido() {
        if (pedidosPendientes.isEmpty()) {
            return null;
        }

        return pedidosPendientes.remove(0);
    }

    public synchronized int cantidadPedidos() {
        return pedidosPendientes.size();
    }
}
