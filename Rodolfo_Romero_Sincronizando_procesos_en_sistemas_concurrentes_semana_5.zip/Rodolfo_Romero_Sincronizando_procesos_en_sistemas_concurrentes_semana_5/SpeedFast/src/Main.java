import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class Main {

    public static void main(String[] args) {

        System.out.println("Sincronización de entregas\n");

        ControladorDeEnvios controlador = new ControladorDeEnvios();
        ZonaDeCarga zonaDeCarga = new ZonaDeCarga();

        // Se agregan seis pedidos a la zona de carga compartida.
        zonaDeCarga.agregarPedido(new PedidoComida(
                101, "Puente alto", 5));
        zonaDeCarga.agregarPedido(new PedidoEncomienda(
                102, "Vicuña", 7));
        zonaDeCarga.agregarPedido(new PedidoExpress(
                103, "Pirque", 4));
        zonaDeCarga.agregarPedido(new PedidoComida(
                104, "Las viscachas", 6));
        zonaDeCarga.agregarPedido(new PedidoEncomienda(
                105, "Lo Curro", 8));
        zonaDeCarga.agregarPedido(new PedidoExpress(
                106, "La Florida", 3));

        System.out.println();

        // Zona De Carga.
        Repartidor juan = new Repartidor("Juan", zonaDeCarga, controlador);
        Repartidor camila = new Repartidor("Camila", zonaDeCarga, controlador);
        Repartidor pedro = new Repartidor("Pedro", zonaDeCarga, controlador);

        ExecutorService executor = Executors.newFixedThreadPool(3);

        executor.execute(juan);
        executor.execute(camila);
        executor.execute(pedro);

        executor.shutdown();

        try {
            boolean terminaron = executor.awaitTermination(1, TimeUnit.MINUTES);

            if (terminaron) {
                System.out.println("\nTodos los pedidos han sido entregados correctamente");
            } else {
                System.out.println("\nEl tiempo de espera terminó antes de completar las entregas.");
                executor.shutdownNow();
            }

        } catch (InterruptedException e) {
            System.out.println("La ejecución principal fue interrumpida.");
            executor.shutdownNow();
            Thread.currentThread().interrupt();
        }

        controlador.verHistorial();
    }
}
