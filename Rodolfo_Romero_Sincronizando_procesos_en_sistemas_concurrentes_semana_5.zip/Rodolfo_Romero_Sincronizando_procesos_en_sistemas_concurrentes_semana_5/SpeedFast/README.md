# SpeedFast - Semana 5

Proyecto de Desarrollo Orientado a Objetos II para IntelliJ IDEA.

## Contenidos implementados

- Programación concurrente con `Runnable` y `ExecutorService`.
- Tres repartidores ejecutándose en paralelo.
- `EstadoPedido` con los estados `PENDIENTE`, `EN_REPARTO` y `ENTREGADO`.
- `ZonaDeCarga` como recurso compartido.
- Métodos `synchronized` para impedir que dos repartidores retiren el mismo pedido.
- Uso de `Thread.sleep()` para simular el tiempo de entrega.
- Manejo de `InterruptedException`.
- Historial de entregas protegido con sincronización.

## Cómo ejecutar en IntelliJ IDEA

1. Descomprimir el archivo ZIP.
2. Abrir la carpeta `SpeedFast` en IntelliJ IDEA.
3. Verificar que exista un JDK configurado.
4. Abrir `src/Main.java`.
5. Ejecutar `Main.main()` con el botón verde.

La salida puede cambiar de orden en cada ejecución porque los repartidores trabajan de forma concurrente.
